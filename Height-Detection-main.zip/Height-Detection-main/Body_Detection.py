# from _typeshed import SupportsWrite
import cv2 as cv
import mediapipe as mp
from numpy.lib import utils
import time
import math


mpPose = mp.solutions.pose
mpFaceMesh = mp.solutions.face_mesh
facemesh = mpFaceMesh.FaceMesh(max_num_faces = 2)
mpDraw = mp.solutions.drawing_utils
drawing = mpDraw.DrawingSpec(thickness = 1 , circle_radius = 1)
pose = mpPose.Pose()
capture = cv.VideoCapture(0)
lst = []
n = 0
cx2, cy2 = 0, 0 
scale = 3
ptime = 0
count = 0
brake = 0
x=150
y=195

# BMI-based constants
AVERAGE_DENSITY = 1.062  # g/cm³ (average human body density)
BMI_FACTOR = 1.3  # Adjustment factor for BMI calculation

def speak(audio):
    pass

def calculate_body_volume(landmarks, height_cm):
    """Estimate body volume using key landmarks"""
    # Get shoulder width (between landmarks 11 and 12)
    shoulder_width = math.dist(
        [landmarks.landmark[11].x, landmarks.landmark[11].y],
        [landmarks.landmark[12].x, landmarks.landmark[12].y]
    )
    
    # Get hip width (between landmarks 23 and 24)
    hip_width = math.dist(
        [landmarks.landmark[23].x, landmarks.landmark[23].y],
        [landmarks.landmark[24].x, landmarks.landmark[24].y]
    )
    
    # Get chest depth (approximate using landmarks 11 and 23)
    chest_depth = math.dist(
        [landmarks.landmark[11].x, landmarks.landmark[11].y],
        [landmarks.landmark[23].x, landmarks.landmark[23].y]
    )
    
    # Calculate approximate body volume using cylinder method
    avg_width = (shoulder_width + hip_width) / 2
    body_volume = height_cm * avg_width * chest_depth * 1000  # Convert to cm³
    
    return body_volume

def estimate_weight(landmarks, height_cm):
    """Estimate weight based on height and body proportions"""
    if not height_cm:
        return 0
        
    body_volume = calculate_body_volume(landmarks, height_cm)
    estimated_weight = (body_volume * AVERAGE_DENSITY) / 1000  # Convert to kg
    
    # Apply BMI-based adjustment
    height_m = height_cm / 100
    bmi_adjustment = (height_m * height_m) * BMI_FACTOR
    
    final_weight = estimated_weight * bmi_adjustment
    
    return round(final_weight, 1)

while True:
    isTrue,img = capture.read()
    img_rgb = cv.cvtColor(img , cv.COLOR_BGR2RGB)
    result = pose.process(img_rgb)
    if result.pose_landmarks:
        mpDraw.draw_landmarks(img, result.pose_landmarks,mpPose.POSE_CONNECTIONS)
        for id, lm in enumerate(result.pose_landmarks.landmark):
            lst.append([id, lm.x, lm.y])
            n += 1  # Proper increment
            
            h, w, c = img.shape
            if id == 32 or id == 31:
                cx1, cy1 = int(lm.x*w), int(lm.y*h)
                cv.circle(img, (cx1,cy1), 15, (0,0,0), cv.FILLED)
                if cx2 != 0:  # Only calculate distance if cx2 is set
                    d = ((cx2-cx1)**2 + (cy2-cy1)**2)**0.5
                    height_cm = round(d*0.5)
                    
                    # Calculate estimated weight
                    estimated_weight = estimate_weight(result.pose_landmarks, height_cm)
                    
                    # Display height and weight
                    cv.putText(img, "Height : ", (40,70), cv.FONT_HERSHEY_COMPLEX, 1, (255,255,0), thickness=2)
                    cv.putText(img, f"{height_cm}", (180,70), cv.FONT_HERSHEY_DUPLEX, 1, (255,255,0), thickness=2)
                    cv.putText(img, "cms", (240,70), cv.FONT_HERSHEY_PLAIN, 2, (255,255,0), thickness=2)
                    
                    # Add weight display
                    cv.putText(img, "Est. Weight : ", (40,120), cv.FONT_HERSHEY_COMPLEX, 1, (255,255,0), thickness=2)
                    cv.putText(img, f"{estimated_weight}", (220,120), cv.FONT_HERSHEY_DUPLEX, 1, (255,255,0), thickness=2)
                    cv.putText(img, "kg", (300,120), cv.FONT_HERSHEY_PLAIN, 2, (255,255,0), thickness=2)
            if id == 6:
                cx2 , cy2 = int(lm.x*w) , int(lm.y*h)
                # cx2 = cx230
                cy2 = cy2 + 20
                cv.circle(img,(cx2,cy2),15,(0,0,0),cv.FILLED)
    img = cv.resize(img , (700,500))
    ctime = time.time()
    fps = 1/(ctime-ptime)
    ptime=ctime
    cv.putText(img , "FPS : ",(40,30),cv.FONT_HERSHEY_PLAIN,2,(0,0,0),thickness=2)
    cv.putText(img , str(int(fps)),(160,30),cv.FONT_HERSHEY_PLAIN,2,(0,0,0),thickness=2)
    cv.imshow("Task",img)
    if cv.waitKey(20) & 0xFF == ord('q'):
        break
capture.release()
cv.destroyAllWindows()