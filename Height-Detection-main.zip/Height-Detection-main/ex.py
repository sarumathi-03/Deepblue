# install opencv "pip install opencv-python"
import cv2
import os
import pathlib

# Constants
Known_distance = 60.96  # centimeter
Known_width = 14.3     # centimeter

# Colors
GREEN = (0, 255, 0)
RED = (0, 0, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Fonts
fonts = cv2.FONT_HERSHEY_COMPLEX

# Get the current directory
current_dir = pathlib.Path(__file__).parent.absolute()

# Load face detector
cascade_path = os.path.join(current_dir, "haarcascade_frontalface_default.xml")
face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')  # Updated path

def create_reference_image():
    """Create a reference image by capturing from webcam"""
    print("Let's create a reference image first!")
    print("Stand exactly 60.96 cm (24 inches) from camera")
    print("Press 'c' to capture or 'q' to quit")
    
    # Try different camera indices
    for camera_index in [0, 1, 2]:
        print(f"Trying camera index {camera_index}...")
        cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)  # Add CAP_DSHOW
        
        if cap.isOpened():
            print(f"Successfully opened camera {camera_index}")
            break
    else:
        print("Error: Could not open any camera")
        return False
    
    # Set camera properties
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        # Draw guide lines
        frame_center = frame.shape[1] // 2
        cv2.line(frame, (frame_center, 0), (frame_center, frame.shape[0]), GREEN, 1)
        
        # Show distance reminder
        cv2.putText(frame, "Stand at 60.96 cm (24 inches)", (30, 30), fonts, 0.6, GREEN, 2)
        cv2.putText(frame, "Press 'c' to capture", (30, 60), fonts, 0.6, GREEN, 2)
        
        # Detect face
        face_width = face_data(frame)
        
        cv2.imshow("Create Reference Image", frame)
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('c'):
            # Save the frame as reference image
            ref_image_path = os.path.join(current_dir, "Ref_image.jpg")
            cv2.imwrite(ref_image_path, frame)
            print(f"Reference image saved to: {ref_image_path}")
            cap.release()
            cv2.destroyAllWindows()
            return True
            
    cap.release()
    cv2.destroyAllWindows()
    return False

def show_distance_message(frame, distance):
    """Display appropriate distance message on frame"""
    message = ""
    if distance in range(330, 360):
        message = "Perfect distance - Stand still"
        # Launch body detection
        body_detection_path = os.path.join(current_dir, "Body_Detection.py")
        if os.path.exists(body_detection_path):
            os.startfile(body_detection_path)
            return True
    elif distance < 330:
        message = "Step back"
    else:
        message = "Come closer"
    
    # Draw message on frame
    cv2.putText(frame, message, (30, 70), fonts, 0.6, GREEN, 2)
    return False

# Rest of your distance calculation functions remain the same
def Focal_Length_Finder(measured_distance, real_width, width_in_rf_image):
    return (width_in_rf_image * measured_distance) / real_width

def Distance_finder(Focal_Length, real_face_width, face_width_in_frame):
    return (real_face_width * Focal_Length)/face_width_in_frame

def face_data(image):
    face_width = 0
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray_image, 1.3, 5)
    
    for (x, y, h, w) in faces:
        cv2.rectangle(image, (x, y), (x+w, y+h), GREEN, 2)
        face_width = w
    return face_width

# Main execution
def main():
    # Check if reference image exists
    ref_image_path = os.path.join(current_dir, "Ref_image.jpg")
    if not os.path.exists(ref_image_path):
        if not create_reference_image():
            print("Failed to create reference image")
            return
    
    # Continue with the rest of the program...
    ref_image = cv2.imread(ref_image_path)
    if ref_image is None:
        print("Error: Could not load reference image")
        return

    ref_image_face_width = face_data(ref_image)
    Focal_length_found = Focal_Length_Finder(Known_distance, Known_width, ref_image_face_width)

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open camera")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        face_width_in_frame = face_data(frame)
        if face_width_in_frame != 0:
            Distance = Distance_finder(Focal_length_found, Known_width, face_width_in_frame)
            Distance = round(Distance)

            # Draw distance indicator
            cv2.line(frame, (30, 30), (230, 30), RED, 32)
            cv2.line(frame, (30, 30), (230, 30), BLACK, 28)
            cv2.putText(frame, f"Distance: {Distance} cms", (30, 35), fonts, 0.6, GREEN, 2)

            # Show distance message and check if we should exit
            if show_distance_message(frame, Distance):
                break

        cv2.imshow("frame", frame)
        if cv2.waitKey(1) == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
